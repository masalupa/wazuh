"""
wazuh_ssh.py

Wraps an SSH connection to a remote Wazuh manager host and exposes the
operations the web app needs: full filesystem access under /var/ossec,
config validation/restart, and the common agent/group maintenance
commands.

Design choice: every filesystem operation goes through a `sudo <shell
command>` over the SSH exec channel, instead of raw SFTP. /var/ossec is
normally owned by root/wazuh, so a plain SFTP session logged in as a
non-root user would fail on most reads/writes in that tree. Going through
sudo means the SSH login account just needs sudo rights (ideally a
NOPASSWD rule scoped to the specific binaries below - see the notes
shipped alongside this tool) rather than being root itself.
"""

import base64
import posixpath
import shlex
import time

import paramiko


class WazuhSSHError(Exception):
    pass


class WazuhSSHManager:
    def __init__(self, host, port, username, password=None, key_path=None, key_passphrase=None):
        self.host = host
        self.port = port or 22
        self.username = username
        self.password = password
        self.key_path = key_path
        self.key_passphrase = key_passphrase
        self.client = None

    # ------------------------------------------------------------------ #
    # Connection lifecycle
    # ------------------------------------------------------------------ #

    def connect(self, timeout=10):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = dict(hostname=self.host, port=self.port, username=self.username, timeout=timeout)
        if self.key_path:
            kwargs["pkey"] = self._load_private_key(self.key_path, self.key_passphrase)
        elif self.password:
            kwargs["password"] = self.password
        else:
            raise WazuhSSHError("No password or private key configured for this connection.")
        try:
            self.client.connect(**kwargs)
        except Exception as e:  # noqa: BLE001
            raise WazuhSSHError(f"SSH connection to {self.host}:{self.port} failed: {e}") from e

    @staticmethod
    def _load_private_key(path, passphrase):
        last_err = None
        for key_cls in (paramiko.Ed25519Key, paramiko.RSAKey, paramiko.ECDSAKey, paramiko.DSSKey):
            try:
                return key_cls.from_private_key_file(path, password=passphrase)
            except Exception as e:  # noqa: BLE001
                last_err = e
        raise WazuhSSHError(f"Could not load private key {path}: {last_err}")

    def close(self):
        if self.client:
            self.client.close()

    # ------------------------------------------------------------------ #
    # Raw command execution
    # ------------------------------------------------------------------ #

    def run(self, command, timeout=30):
        stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)
        exit_code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8", errors="replace")
        err = stderr.read().decode("utf-8", errors="replace")
        return exit_code, out, err

    def run_ok(self, command, timeout=30):
        code, out, err = self.run(command, timeout=timeout)
        if code != 0:
            raise WazuhSSHError((err or out or f"Command failed (exit {code})").strip())
        return out

    # ------------------------------------------------------------------ #
    # Filesystem operations (all via sudo)
    # ------------------------------------------------------------------ #

    def listdir(self, path):
        cmd = (
            f"sudo find {shlex.quote(path)} -maxdepth 1 -mindepth 1 "
            "-printf '%y|%s|%T@|%f\\n' 2>/dev/null"
        )
        code, out, err = self.run(cmd)
        if code != 0:
            raise WazuhSSHError(err.strip() or f"Could not list {path}")
        entries = []
        for line in out.strip().split("\n"):
            if not line:
                continue
            parts = line.split("|", 3)
            if len(parts) < 4:
                continue
            ftype, size, mtime, name = parts
            entries.append(
                {
                    "name": name,
                    "is_dir": ftype == "d",
                    "is_link": ftype == "l",
                    "size": int(size) if size.isdigit() else 0,
                    "mtime": float(mtime) if mtime else 0.0,
                }
            )
        return sorted(entries, key=lambda e: (not e["is_dir"], e["name"].lower()))

    def stat_size(self, path):
        code, out, err = self.run(f"sudo stat -c '%s' {shlex.quote(path)}")
        if code != 0:
            raise WazuhSSHError(err.strip() or f"Could not stat {path}")
        return int(out.strip())

    def read_file(self, path, max_size=5 * 1024 * 1024):
        size = self.stat_size(path)
        if size > max_size:
            raise WazuhSSHError(
                f"File is {size} bytes, larger than the {max_size}-byte edit limit. Use download instead."
            )
        code, out, err = self.run(f"sudo base64 -w0 {shlex.quote(path)}")
        if code != 0:
            raise WazuhSSHError(err.strip() or f"Could not read {path}")
        return base64.b64decode(out).decode("utf-8", errors="replace")

    def write_file(self, path, content):
        b64 = base64.b64encode(content.encode("utf-8")).decode()
        cmd = f"base64 -d | sudo tee {shlex.quote(path)} > /dev/null"
        stdin, stdout, stderr = self.client.exec_command(cmd)
        stdin.write(b64)
        stdin.channel.shutdown_write()
        exit_code = stdout.channel.recv_exit_status()
        err = stderr.read().decode("utf-8", errors="replace")
        if exit_code != 0:
            raise WazuhSSHError(err.strip() or f"Could not write {path}")

    def backup_file(self, path):
        ts = time.strftime("%Y%m%d_%H%M%S")
        backup_path = f"{path}.bak.{ts}"
        self.run_ok(f"sudo cp -a {shlex.quote(path)} {shlex.quote(backup_path)}")
        return backup_path

    def remove_path(self, path):
        self.run_ok(f"sudo rm -rf {shlex.quote(path)}")

    def mkdir(self, path):
        self.run_ok(f"sudo mkdir -p {shlex.quote(path)}")

    def rename(self, old, new):
        self.run_ok(f"sudo mv {shlex.quote(old)} {shlex.quote(new)}")

    def chown_wazuh(self, path):
        self.run(f"sudo chown wazuh:wazuh {shlex.quote(path)}")
        self.run(f"sudo chmod 660 {shlex.quote(path)}")

    # ------------------------------------------------------------------ #
    # Wazuh-specific operations
    # ------------------------------------------------------------------ #

    def validate_config(self):
        code, out, err = self.run("sudo /var/ossec/bin/wazuh-control configtest")
        return code == 0, (out + err)

    def restart_manager(self):
        return self.run_ok("sudo systemctl restart wazuh-manager")

    def manager_status(self):
        code, out, err = self.run("sudo /var/ossec/bin/wazuh-control status")
        return out + err

    def list_agents(self):
        code, out, err = self.run("sudo /var/ossec/bin/agent_control -l")
        if code == 0:
            return out
        return (
            "agent_control tidak tersedia pada versi Wazuh ini.\n"
            "Gunakan Wazuh Dashboard (Server management > Endpoints) atau Wazuh API:\n"
            "  POST https://<manager>:55000/security/user/authenticate\n"
            "  GET  https://<manager>:55000/agents\n"
            f"(detail error: {err.strip()})"
        )

    def create_group(self, group_name):
        return self.run_ok(f"sudo /var/ossec/bin/agent_groups -a -g {shlex.quote(group_name)} -q")

    def assign_group(self, agent_id, group_name):
        return self.run_ok(
            f"sudo /var/ossec/bin/agent_groups -a -i {shlex.quote(agent_id)} -g {shlex.quote(group_name)} -q"
        )

    def remove_from_group(self, agent_id, group_name):
        return self.run_ok(
            f"sudo /var/ossec/bin/agent_groups -r -i {shlex.quote(agent_id)} -g {shlex.quote(group_name)} -q"
        )

    def list_groups(self):
        code, out, err = self.run("sudo /var/ossec/bin/agent_groups -l")
        return out if code == 0 else (err or out)

    def verify_agent_conf(self):
        code, out, err = self.run("sudo /var/ossec/bin/verify-agent-conf")
        return out + err

    def backup_full_config(self):
        ts = time.strftime("%Y%m%d_%H%M%S")
        backup_path = f"/var/ossec/automation_backups/webtool_{ts}.tar.gz"
        self.run_ok("sudo mkdir -p /var/ossec/automation_backups")
        self.run_ok(
            "sudo tar czf " + shlex.quote(backup_path) +
            " -C /var/ossec/etc ossec.conf rules decoders shared"
        )
        return backup_path

    def list_backups(self):
        code, out, err = self.run(
            "sudo find /var/ossec/automation_backups -maxdepth 1 -name 'webtool_*.tar.gz' "
            "-printf '%f|%s|%T@\\n' 2>/dev/null"
        )
        backups = []
        for line in out.strip().split("\n"):
            if not line:
                continue
            parts = line.split("|")
            if len(parts) != 3:
                continue
            name, size, mtime = parts
            backups.append({"name": name, "size": int(size), "mtime": float(mtime)})
        return sorted(backups, key=lambda b: b["mtime"], reverse=True)

    def restore_backup(self, backup_name):
        backup_path = posixpath.join("/var/ossec/automation_backups", backup_name)
        self.run_ok(f"sudo tar xzf {shlex.quote(backup_path)} -C /var/ossec/etc")
