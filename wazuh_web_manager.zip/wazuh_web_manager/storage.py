"""
storage.py

Local SQLite storage for the Wazuh Web Manager:
  - users: who may log into this web tool
  - connections: saved SSH connection profiles for one or more Wazuh
    manager hosts. Secrets (SSH password or private-key passphrase) are
    encrypted at rest with a Fernet key stored in secret.key next to the
    database. Protect both files with filesystem permissions - anyone who
    can read secret.key + wazuh_webtool.db can decrypt stored secrets.
"""

import os
import sqlite3

from cryptography.fernet import Fernet
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "wazuh_webtool.db")
KEY_PATH = os.path.join(BASE_DIR, "secret.key")


def _get_fernet():
    if not os.path.exists(KEY_PATH):
        key = Fernet.generate_key()
        with open(KEY_PATH, "wb") as f:
            f.write(key)
        os.chmod(KEY_PATH, 0o600)
    with open(KEY_PATH, "rb") as f:
        key = f.read()
    return Fernet(key)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS connections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            host TEXT NOT NULL,
            port INTEGER NOT NULL DEFAULT 22,
            username TEXT NOT NULL,
            auth_type TEXT NOT NULL,       -- 'password' or 'key'
            secret_encrypted TEXT,         -- encrypted password or key passphrase
            key_path TEXT                  -- path to private key FILE ON THE SERVER RUNNING THIS APP
        )
        """
    )
    conn.commit()
    conn.close()
    if os.path.exists(DB_PATH):
        os.chmod(DB_PATH, 0o600)


# --------------------------------------------------------------------------- #
# Users
# --------------------------------------------------------------------------- #

def create_user(username, password):
    conn = get_db()
    conn.execute(
        "INSERT INTO users (username, password_hash) VALUES (?, ?)",
        (username, generate_password_hash(password)),
    )
    conn.commit()
    conn.close()


def get_user_by_username(username):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    return row


def verify_user(username, password):
    row = get_user_by_username(username)
    if row and check_password_hash(row["password_hash"], password):
        return row
    return None


def any_user_exists():
    conn = get_db()
    row = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()
    conn.close()
    return row["c"] > 0


# --------------------------------------------------------------------------- #
# Connections
# --------------------------------------------------------------------------- #

def save_connection(name, host, port, username, auth_type, secret=None, key_path=None):
    fernet = _get_fernet()
    enc = fernet.encrypt(secret.encode()).decode() if secret else None
    conn = get_db()
    conn.execute(
        """INSERT INTO connections (name, host, port, username, auth_type, secret_encrypted, key_path)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (name, host, port, username, auth_type, enc, key_path),
    )
    conn.commit()
    conn.close()


def list_connections():
    conn = get_db()
    rows = conn.execute(
        "SELECT id, name, host, port, username, auth_type, key_path FROM connections ORDER BY name"
    ).fetchall()
    conn.close()
    return rows


def get_connection(conn_id):
    if not conn_id:
        return None
    conn = get_db()
    row = conn.execute("SELECT * FROM connections WHERE id = ?", (conn_id,)).fetchone()
    conn.close()
    return row


def get_connection_secret(conn_id):
    row = get_connection(conn_id)
    if not row or not row["secret_encrypted"]:
        return None
    fernet = _get_fernet()
    return fernet.decrypt(row["secret_encrypted"].encode()).decode()


def delete_connection(conn_id):
    conn = get_db()
    conn.execute("DELETE FROM connections WHERE id = ?", (conn_id,))
    conn.commit()
    conn.close()
