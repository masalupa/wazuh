"""
app.py

Wazuh Web Manager - a small internal web app to:
  - connect remotely (over SSH) to one or more Wazuh manager hosts
  - browse, view, edit, upload, download, rename and delete any file
    under /var/ossec
  - validate config + backup + restart the manager safely
  - manage agent groups and see agent status
  - take/restore full config backups

Run:
    pip install -r requirements.txt
    python3 app.py
Then open http://127.0.0.1:5000 - the first visit creates the admin account.

SECURITY NOTES (read before exposing this beyond localhost):
  - This app gives full read/write access to /var/ossec on every manager
    you connect it to. Treat it like a root shell to that host.
  - Put it behind HTTPS and a VPN/firewall if it must be reached off the
    machine it runs on - do not expose it directly to the internet.
  - SSH secrets are encrypted at rest (storage.py), but the Flask session
    cookie is the only thing protecting access to this app itself -
    always change app.secret_key to a fixed, random value in production
    (see the WAZUH_WEBTOOL_SECRET environment variable below) so
    restarting the app doesn't invalidate every session, and so the key
    isn't regenerated (and thus guessable-by-restart) on every boot.
"""

import io
import os
import posixpath
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for, session, flash,
    send_file, abort
)

import storage
from wazuh_ssh import WazuhSSHManager, WazuhSSHError

ROOT_DIR = "/var/ossec"

app = Flask(__name__)
app.secret_key = os.environ.get("WAZUH_WEBTOOL_SECRET", os.urandom(32))

storage.init_db()


# --------------------------------------------------------------------------- #
# Decorators / helpers
# --------------------------------------------------------------------------- #

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def connection_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("connection_id"):
            flash("Pilih koneksi Wazuh manager terlebih dahulu.", "warning")
            return redirect(url_for("connections"))
        return view(*args, **kwargs)
    return wrapped


def get_ssh():
    conn_id = session.get("connection_id")
    row = storage.get_connection(conn_id)
    if not row:
        abort(400, "Connection not found")
    secret = storage.get_connection_secret(conn_id)
    mgr = WazuhSSHManager(
        host=row["host"],
        port=row["port"],
        username=row["username"],
        password=secret if row["auth_type"] == "password" else None,
        key_path=row["key_path"] if row["auth_type"] == "key" else None,
        key_passphrase=secret if row["auth_type"] == "key" else None,
    )
    mgr.connect()
    return mgr


def safe_path(path):
    norm = posixpath.normpath(path or "/")
    if not norm.startswith("/"):
        norm = "/" + norm
    return norm


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #

@app.route("/setup", methods=["GET", "POST"])
def setup():
    if storage.any_user_exists():
        return redirect(url_for("login"))
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        if not username or not password:
            flash("Username dan password wajib diisi.", "danger")
        else:
            storage.create_user(username, password)
            flash("Akun admin dibuat, silakan login.", "success")
            return redirect(url_for("login"))
    return render_template("setup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if not storage.any_user_exists():
        return redirect(url_for("setup"))
    if request.method == "POST":
        user = storage.verify_user(request.form["username"], request.form["password"])
        if user:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Username atau password salah.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# --------------------------------------------------------------------------- #
# Dashboard / quick actions
# --------------------------------------------------------------------------- #

@app.route("/")
@login_required
def dashboard():
    row = None
    status = None
    error = None
    if session.get("connection_id"):
        row = storage.get_connection(session["connection_id"])
        mgr = None
        try:
            mgr = get_ssh()
            status = mgr.manager_status()
        except Exception as e:  # noqa: BLE001
            error = str(e)
        finally:
            if mgr:
                mgr.close()
    return render_template("dashboard.html", connection=row, status=status, error=error)


@app.route("/action/validate", methods=["POST"])
@login_required
@connection_required
def action_validate():
    mgr = get_ssh()
    try:
        ok, output = mgr.validate_config()
        flash(output or "(tidak ada output)", "success" if ok else "danger")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("dashboard"))


@app.route("/action/restart", methods=["POST"])
@login_required
@connection_required
def action_restart():
    mgr = get_ssh()
    try:
        mgr.restart_manager()
        flash("wazuh-manager berhasil di-restart.", "success")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("dashboard"))


@app.route("/action/backup-config", methods=["POST"])
@login_required
@connection_required
def action_backup_config():
    mgr = get_ssh()
    try:
        path = mgr.backup_full_config()
        flash(f"Backup dibuat: {path}", "success")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("backups"))


# --------------------------------------------------------------------------- #
# Connections
# --------------------------------------------------------------------------- #

@app.route("/connections", methods=["GET", "POST"])
@login_required
def connections():
    if request.method == "POST":
        auth_type = request.form["auth_type"]
        secret = (
            request.form.get("secret_password")
            if auth_type == "password"
            else request.form.get("secret_passphrase")
        ) or None
        storage.save_connection(
            name=request.form["name"],
            host=request.form["host"],
            port=int(request.form.get("port") or 22),
            username=request.form["username"],
            auth_type=auth_type,
            secret=secret,
            key_path=request.form.get("key_path") or None,
        )
        flash("Koneksi disimpan.", "success")
        return redirect(url_for("connections"))
    rows = storage.list_connections()
    return render_template("connections.html", connections=rows, active_id=session.get("connection_id"))


@app.route("/connections/<int:conn_id>/select", methods=["POST"])
@login_required
def select_connection(conn_id):
    session["connection_id"] = conn_id
    flash("Koneksi aktif diubah.", "success")
    return redirect(url_for("dashboard"))


@app.route("/connections/<int:conn_id>/delete", methods=["POST"])
@login_required
def delete_connection_route(conn_id):
    storage.delete_connection(conn_id)
    if session.get("connection_id") == conn_id:
        session.pop("connection_id", None)
    flash("Koneksi dihapus.", "success")
    return redirect(url_for("connections"))


@app.route("/connections/<int:conn_id>/test", methods=["POST"])
@login_required
def test_connection(conn_id):
    row = storage.get_connection(conn_id)
    secret = storage.get_connection_secret(conn_id)
    mgr = WazuhSSHManager(
        host=row["host"], port=row["port"], username=row["username"],
        password=secret if row["auth_type"] == "password" else None,
        key_path=row["key_path"] if row["auth_type"] == "key" else None,
        key_passphrase=secret if row["auth_type"] == "key" else None,
    )
    try:
        mgr.connect()
        mgr.run_ok("echo ok")
        flash(f"Koneksi ke {row['host']} berhasil.", "success")
    except Exception as e:  # noqa: BLE001
        flash(f"Koneksi gagal: {e}", "danger")
    finally:
        mgr.close()
    return redirect(url_for("connections"))


# --------------------------------------------------------------------------- #
# File browser / editor
# --------------------------------------------------------------------------- #

@app.route("/files")
@login_required
@connection_required
def files():
    path = safe_path(request.args.get("path", ROOT_DIR))
    mgr = get_ssh()
    try:
        entries = mgr.listdir(path)
    except WazuhSSHError as e:
        flash(str(e), "danger")
        entries = []
    finally:
        mgr.close()
    parent = posixpath.dirname(path.rstrip("/")) or "/"
    return render_template("files.html", path=path, parent=parent, entries=entries, root=ROOT_DIR)


@app.route("/files/edit")
@login_required
@connection_required
def files_edit():
    path = safe_path(request.args.get("path"))
    mgr = get_ssh()
    try:
        content = mgr.read_file(path)
        error = None
    except WazuhSSHError as e:
        content = ""
        error = str(e)
    finally:
        mgr.close()
    return render_template("editor.html", path=path, content=content, error=error)


@app.route("/files/save", methods=["POST"])
@login_required
@connection_required
def files_save():
    path = safe_path(request.form["path"])
    content = request.form["content"]
    restart_after = request.form.get("restart_after") == "on"

    mgr = get_ssh()
    backup_path = None
    try:
        backup_path = mgr.backup_file(path)
        mgr.write_file(path, content)

        is_config_file = (
            path.startswith(f"{ROOT_DIR}/etc/rules/") or
            path.startswith(f"{ROOT_DIR}/etc/decoders/") or
            path.startswith(f"{ROOT_DIR}/etc/shared/") or
            path == f"{ROOT_DIR}/etc/ossec.conf"
        )

        if is_config_file:
            ok, output = mgr.validate_config()
            if not ok:
                mgr.run_ok(f"sudo cp -a '{backup_path}' '{path}'")
                flash(f"Validasi gagal, perubahan dibatalkan otomatis (rollback):\n{output}", "danger")
                return redirect(url_for("files_edit", path=path))
            flash(f"Tersimpan & konfigurasi valid. Backup: {backup_path}", "success")
            if restart_after:
                mgr.restart_manager()
                flash("wazuh-manager telah di-restart.", "success")
        else:
            flash(f"File tersimpan. Backup: {backup_path}", "success")

    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("files_edit", path=path))


@app.route("/files/download")
@login_required
@connection_required
def files_download():
    path = safe_path(request.args.get("path"))
    mgr = get_ssh()
    try:
        content = mgr.read_file(path, max_size=50 * 1024 * 1024)
    except WazuhSSHError as e:
        flash(str(e), "danger")
        return redirect(url_for("files", path=posixpath.dirname(path)))
    finally:
        mgr.close()
    buf = io.BytesIO(content.encode("utf-8"))
    return send_file(buf, as_attachment=True, download_name=posixpath.basename(path))


@app.route("/files/upload", methods=["POST"])
@login_required
@connection_required
def files_upload():
    target_dir = safe_path(request.form["path"])
    uploaded = request.files.get("file")
    if not uploaded or not uploaded.filename:
        flash("Tidak ada file yang dipilih.", "danger")
        return redirect(url_for("files", path=target_dir))
    dest_path = posixpath.join(target_dir, uploaded.filename)
    content = uploaded.read().decode("utf-8", errors="replace")
    mgr = get_ssh()
    try:
        mgr.write_file(dest_path, content)
        flash(f"Diunggah ke {dest_path}", "success")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("files", path=target_dir))


@app.route("/files/mkdir", methods=["POST"])
@login_required
@connection_required
def files_mkdir():
    parent = safe_path(request.form["path"])
    name = request.form["name"].strip()
    mgr = get_ssh()
    try:
        mgr.mkdir(posixpath.join(parent, name))
        flash("Folder dibuat.", "success")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("files", path=parent))


@app.route("/files/delete", methods=["POST"])
@login_required
@connection_required
def files_delete():
    path = safe_path(request.form["path"])
    parent = posixpath.dirname(path.rstrip("/")) or "/"
    mgr = get_ssh()
    try:
        mgr.remove_path(path)
        flash("Dihapus.", "success")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("files", path=parent))


@app.route("/files/rename", methods=["POST"])
@login_required
@connection_required
def files_rename():
    path = safe_path(request.form["path"])
    new_name = request.form["new_name"].strip()
    parent = posixpath.dirname(path.rstrip("/")) or "/"
    new_path = posixpath.join(parent, new_name)
    mgr = get_ssh()
    try:
        mgr.rename(path, new_path)
        flash("Berhasil diganti nama.", "success")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("files", path=parent))


# --------------------------------------------------------------------------- #
# Groups
# --------------------------------------------------------------------------- #

@app.route("/groups", methods=["GET", "POST"])
@login_required
@connection_required
def groups():
    mgr = get_ssh()
    listing = ""
    try:
        if request.method == "POST":
            action = request.form.get("action")
            if action == "create":
                mgr.create_group(request.form["name"])
                flash("Grup dibuat.", "success")
            elif action == "assign":
                mgr.assign_group(request.form["agent_id"], request.form["group"])
                flash("Agent berhasil di-assign ke grup.", "success")
            elif action == "unassign":
                mgr.remove_from_group(request.form["agent_id"], request.form["group"])
                flash("Agent dikeluarkan dari grup.", "success")
        listing = mgr.list_groups()
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return render_template("groups.html", listing=listing)


# --------------------------------------------------------------------------- #
# Agents
# --------------------------------------------------------------------------- #

@app.route("/agents")
@login_required
@connection_required
def agents():
    mgr = get_ssh()
    try:
        listing = mgr.list_agents()
    except WazuhSSHError as e:
        flash(str(e), "danger")
        listing = ""
    finally:
        mgr.close()
    return render_template("agents.html", listing=listing)


# --------------------------------------------------------------------------- #
# Backups
# --------------------------------------------------------------------------- #

@app.route("/backups")
@login_required
@connection_required
def backups():
    mgr = get_ssh()
    try:
        items = mgr.list_backups()
    except WazuhSSHError as e:
        flash(str(e), "danger")
        items = []
    finally:
        mgr.close()
    return render_template("backups.html", backups=items)


@app.route("/backups/restore", methods=["POST"])
@login_required
@connection_required
def backups_restore():
    name = request.form["name"]
    mgr = get_ssh()
    try:
        mgr.restore_backup(name)
        ok, output = mgr.validate_config()
        if ok:
            flash("Backup berhasil di-restore & konfigurasi valid. Restart manager agar berlaku.", "success")
        else:
            flash(f"Backup di-restore tapi konfigurasi TIDAK valid:\n{output}", "danger")
    except WazuhSSHError as e:
        flash(str(e), "danger")
    finally:
        mgr.close()
    return redirect(url_for("backups"))


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
